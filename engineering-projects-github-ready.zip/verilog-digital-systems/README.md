# Verilog Digital Systems

> Collection of Verilog and digital systems work documenting RTL design, simulation and digital logic development.

## Overview

This repository will document Verilog projects and digital systems work, including RTL implementations, finite-state machines and simulation results.

## Project Goals

- Practice RTL design using Verilog
- Translate digital logic concepts into synthesizable hardware descriptions
- Design and analyze finite-state machines
- Build testbenches and verify RTL behavior
- Document design decisions and simulation results

## Project Structure

```text
src/          RTL / Verilog source files
testbench/    Testbenches
simulations/  Simulation outputs and waveforms
images/       Diagrams and project visuals
docs/         Design notes and supporting documentation
```

## RTL Designs

Designs will be added as the original Verilog work is organized.

## Finite-State Machines

FSM implementations, state diagrams and design notes will be documented here.

## Verification

Testbenches and simulation results will be added alongside each RTL design.

## Simulation Results

Waveforms and other verification evidence will be added here.

## Lessons Learned

This section will document lessons from RTL design, debugging and verification.

## Future Work

Potential extensions include additional RTL modules, stronger test coverage and FPGA implementation.

---
*Project documentation is being organized from the original digital systems and Verilog work.*
