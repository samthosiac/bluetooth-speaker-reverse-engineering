# FM Radio Receiver

> Engineering project documenting the design, assembly, testing and enclosure development of an FM radio receiver.

## Overview

This repository will document the FM radio receiver project from the original design and circuit work through physical assembly, testing and CAD enclosure development.

## Project Goals

- Build and test an FM radio receiver
- Document the circuit and hardware
- Record measurements and test results
- Develop and evaluate a physical enclosure
- Connect the design process to practical electrical engineering concepts

## Hardware & Tools

Details will be added from the original project files.

## Circuit Design

Original schematics and circuit documentation will be added here.

## Hardware Assembly

Photos and documentation of the physical build will be added here.

## Testing & Measurements

Measured values, test procedures and results will be documented here.

## CAD / Enclosure

CAD files, drawings and enclosure fit checks will be added here.

## Results

Final results will be added after the original project materials are organized.

## Challenges & Lessons Learned

This section will document design challenges, troubleshooting and lessons learned from the build.

## Future Improvements

Potential improvements will be documented based on the final project and testing.

## Project Documentation

See the folders in this repository for schematics, CAD, measurements, images and supporting documentation.

---
*Project documentation is being organized from the original engineering coursework and build materials.*
